<?php

require_once __DIR__ . '/php-autoloader/autoload_init.php';

AutoloaderInit::getLoader();