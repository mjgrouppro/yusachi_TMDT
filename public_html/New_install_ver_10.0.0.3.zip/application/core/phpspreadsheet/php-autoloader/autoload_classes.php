<?php

$vendorDir = dirname(dirname(__FILE__));
$baseDir = dirname($vendorDir);

return array(
	$vendorDir . '/psr/simple-cache',
	$vendorDir . '/myclabs/php-enum',
    $vendorDir . '/maennchen/zipstream-php',
    $vendorDir . '/phpoffice/phpspreadsheet',
);
