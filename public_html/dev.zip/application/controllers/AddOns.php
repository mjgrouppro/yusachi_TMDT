<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class AddOns extends MY_Controller {
	function __construct() {
		parent::__construct();
		___construct(1);
	}
}

